<?php
/*******************************************************************************************/
/*
/*        Designed by 'AS Designing'
/*        Web: http://www.asdesigning.com
/*        Web: http://www.astemplates.com
/*        License: GNU/GPL
/*
/*******************************************************************************************/

$css = $params->get('as_slider_css');

?>
 
<style type="text/css">

<?php  
	echo $css;
?>

</style>