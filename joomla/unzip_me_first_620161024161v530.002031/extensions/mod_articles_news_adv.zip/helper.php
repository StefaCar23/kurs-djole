<?php
/**
 * Articles Newsflash Advanced
 *
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 
 * 
*/

defined('_JEXEC') or die;

require_once JPATH_SITE.'/modules/mod_articles_news/helper.php';
