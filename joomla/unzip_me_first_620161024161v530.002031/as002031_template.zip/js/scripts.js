
/***************************************************************************************/
/*
/*		Designed by 'AS Designing'
/*		Web: http://www.asdesigning.com
/*		Email: info@asdesigning.com
/*		License: GNU/GPL
/*
/**************************************************************************************/

var asjQuery = jQuery.noConflict();

/************************************/
/*		Toggling					*/

asjQuery(document).ready(function()
{
	asjQuery(".toggle.1").click(function(){
		asjQuery(".toggle_content.1").slideToggle();
		if(asjQuery(".toggle.1").hasClass("opened"))
			asjQuery(".toggle.1").removeClass("opened")	
		else
			asjQuery(".toggle.1").addClass("opened")
	});
	asjQuery(".toggle.2").click(function(){
		asjQuery(".toggle_content.2").slideToggle();
		if(asjQuery(".toggle.2").hasClass("opened"))
			asjQuery(".toggle.2").removeClass("opened")	
		else
			asjQuery(".toggle.2").addClass("opened")
	});
	asjQuery(".toggle.3").click(function(){
		asjQuery(".toggle_content.3").slideToggle();
		if(asjQuery(".toggle.3").hasClass("opened"))
			asjQuery(".toggle.3").removeClass("opened")	
		else
			asjQuery(".toggle.3").addClass("opened")
	});
	asjQuery(".toggle.4").click(function(){
		asjQuery(".toggle_content.4").slideToggle();
		if(asjQuery(".toggle.4").hasClass("opened"))
			asjQuery(".toggle.4").removeClass("opened")	
		else
			asjQuery(".toggle.4").addClass("opened")
	});
	asjQuery(".toggle.5").click(function(){
		asjQuery(".toggle_content.5").slideToggle();
		if(asjQuery(".toggle.5").hasClass("opened"))
			asjQuery(".toggle.5").removeClass("opened")	
		else
			asjQuery(".toggle.5").addClass("opened")
	});
	asjQuery(".toggle.6").click(function(){
		asjQuery(".toggle_content.6").slideToggle();
		if(asjQuery(".toggle.6").hasClass("opened"))
			asjQuery(".toggle.6").removeClass("opened")	
		else
			asjQuery(".toggle.6").addClass("opened")
	});
	asjQuery(".toggle.7").click(function(){
		asjQuery(".toggle_content.7").slideToggle();
		if(asjQuery(".toggle.7").hasClass("opened"))
			asjQuery(".toggle.7").removeClass("opened")	
		else
			asjQuery(".toggle.7").addClass("opened")
	});
	asjQuery(".toggle.8").click(function(){
		asjQuery(".toggle_content.8").slideToggle();
		if(asjQuery(".toggle.8").hasClass("opened"))
			asjQuery(".toggle.8").removeClass("opened")	
		else
			asjQuery(".toggle.8").addClass("opened")
	});
	asjQuery(".toggle.9").click(function(){
		asjQuery(".toggle_content.9").slideToggle();
		if(asjQuery(".toggle.9").hasClass("opened"))
			asjQuery(".toggle.9").removeClass("opened")	
		else
			asjQuery(".toggle.9").addClass("opened")
	});
	asjQuery(".toggle.10").click(function(){
		asjQuery(".toggle_content.10").slideToggle();
		if(asjQuery(".toggle.10").hasClass("opened"))
			asjQuery(".toggle.10").removeClass("opened")	
		else
			asjQuery(".toggle.10").addClass("opened")
	});
	asjQuery(".toggle.11").click(function(){
		asjQuery(".toggle_content.11").slideToggle();
		if(asjQuery(".toggle.11").hasClass("opened"))
			asjQuery(".toggle.11").removeClass("opened")	
		else
			asjQuery(".toggle.11").addClass("opened")
	});
	asjQuery(".toggle.12").click(function(){
		asjQuery(".toggle_content.12").slideToggle();
		if(asjQuery(".toggle.12").hasClass("opened"))
			asjQuery(".toggle.12").removeClass("opened")	
		else
			asjQuery(".toggle.12").addClass("opened")
	});
	asjQuery(".toggle.13").click(function(){
		asjQuery(".toggle_content.13").slideToggle();
		if(asjQuery(".toggle.13").hasClass("opened"))
			asjQuery(".toggle.13").removeClass("opened")	
		else
			asjQuery(".toggle.13").addClass("opened")
	});
	asjQuery(".toggle.14").click(function(){
		asjQuery(".toggle_content.14").slideToggle();
		if(asjQuery(".toggle.14").hasClass("opened"))
			asjQuery(".toggle.14").removeClass("opened")	
		else
			asjQuery(".toggle.14").addClass("opened")
	});
	asjQuery(".toggle.15").click(function(){
		asjQuery(".toggle_content.15").slideToggle();
		if(asjQuery(".toggle.15").hasClass("opened"))
			asjQuery(".toggle.15").removeClass("opened")	
		else
			asjQuery(".toggle.15").addClass("opened")
	});
	asjQuery(".toggle.16").click(function(){
		asjQuery(".toggle_content.16").slideToggle();
		if(asjQuery(".toggle.16").hasClass("opened"))
			asjQuery(".toggle.16").removeClass("opened")	
		else
			asjQuery(".toggle.16").addClass("opened")
	});
	asjQuery(".toggle.17").click(function(){
		asjQuery(".toggle_content.17").slideToggle();
		if(asjQuery(".toggle.17").hasClass("opened"))
			asjQuery(".toggle.17").removeClass("opened")	
		else
			asjQuery(".toggle.17").addClass("opened")
	});
	asjQuery(".toggle.18").click(function(){
		asjQuery(".toggle_content.18").slideToggle();
		if(asjQuery(".toggle.18").hasClass("opened"))
			asjQuery(".toggle.18").removeClass("opened")	
		else
			asjQuery(".toggle.18").addClass("opened")
	});
	asjQuery(".toggle.19").click(function(){
		asjQuery(".toggle_content.19").slideToggle();
		if(asjQuery(".toggle.19").hasClass("opened"))
			asjQuery(".toggle.19").removeClass("opened")	
		else
			asjQuery(".toggle.19").addClass("opened")
	});
	asjQuery(".toggle.20").click(function(){
		asjQuery(".toggle_content.20").slideToggle();
		if(asjQuery(".toggle.20").hasClass("opened"))
			asjQuery(".toggle.20").removeClass("opened")	
		else
			asjQuery(".toggle.20").addClass("opened")
	});
	asjQuery(".toggle.21").click(function(){
		asjQuery(".toggle_content.21").slideToggle();
		if(asjQuery(".toggle.21").hasClass("opened"))
			asjQuery(".toggle.21").removeClass("opened")	
		else
			asjQuery(".toggle.21").addClass("opened")
	});
	asjQuery(".toggle.22").click(function(){
		asjQuery(".toggle_content.22").slideToggle();
		if(asjQuery(".toggle.22").hasClass("opened"))
			asjQuery(".toggle.22").removeClass("opened")	
		else
			asjQuery(".toggle.22").addClass("opened")
	});
	asjQuery(".toggle.23").click(function(){
		asjQuery(".toggle_content.23").slideToggle();
		if(asjQuery(".toggle.23").hasClass("opened"))
			asjQuery(".toggle.23").removeClass("opened")	
		else
			asjQuery(".toggle.23").addClass("opened")
	});
	asjQuery(".toggle.24").click(function(){
		asjQuery(".toggle_content.24").slideToggle();
		if(asjQuery(".toggle.24").hasClass("opened"))
			asjQuery(".toggle.24").removeClass("opened")	
		else
			asjQuery(".toggle.24").addClass("opened")
	});
	asjQuery(".toggle.25").click(function(){
		asjQuery(".toggle_content.25").slideToggle();
		if(asjQuery(".toggle.25").hasClass("opened"))
			asjQuery(".toggle.25").removeClass("opened")	
		else
			asjQuery(".toggle.25").addClass("opened")
	});	
});


asjQuery(document).ready(function() 
{
	asjQuery('ul li:last-child').addClass('lastItem');
	asjQuery('ul li:first-child').addClass('firstItem');

	asjQuery('*[rel=tooltip]').tooltip()
	asjQuery('*[rel=popover]').popover()
	asjQuery('.tip-bottom').tooltip(
	{placement: "bottom"});


	//************************************
	// Modal Window
	//************************************
	asjQuery('[href="#modal"]').click(function()
	{
		asjQuery('#modal').modal('toggle');
	});
	
	asjQuery('#modal button.modalClose').click(function()
	{
		asjQuery('#modal').modal('hide');
	});
	
	
	//************************************
	// Initialize the gallery touch
	//************************************
	asjQuery('a.touchGalleryLink').touchTouch();
	
	
	//************************************
	// Dropdown icons
	//************************************
	asjQuery('.dropdown-toggle').dropdown()
	
	
	//************************************
	// Gallery Hover Animation
	//************************************
	jQuery('a.zoom').hover(function()
	{
		asjQuery(this).find('span.zoom-bg').stop(true, true).animate({opacity: 0.7}, 100);
		asjQuery(this).find('span.zoom-icon').stop(true, true).animate({top:'50%'}, 100);
		},function(){
		asjQuery(this).find('span.zoom-bg').stop(true, true).animate({opacity: 0}, 100);
		asjQuery(this).find('span.zoom-icon').stop(true, true).animate({top:'-50%'}, 100);
	});
	
	
	//************************************
	// Hide #back-top first
	//************************************
	asjQuery("#back-top").hide();
		
		
	//************************************
	// Fade in #back-top
	//************************************		
	asjQuery(function () 
	{
		asjQuery(window).scroll(function () 
		{
			if (jQuery(this).scrollTop() > 100) 
			{
				asjQuery('#back-top').fadeIn();
			} 
			else 
			{
				asjQuery('#back-top').fadeOut();
			}
		});
	
		//************************************
		// Scroll body to 0px on click
		//************************************	
		asjQuery('#back-top a').click(function () 
		{
			asjQuery('body,html').animate(
			{
				scrollTop: 0
			}, 400);
			return false;
		});
	});
	
	
	//************************************
	// Pagination Active Button
	//************************************
	asjQuery('div.pagination ul li:not([class])').addClass('num');
	
	asjQuery(function()
	{
		//************************************
		// IPad/IPhone
		//************************************		
		var viewportmeta = document.querySelector && document.querySelector('meta[name="viewport"]'),
		ua = navigator.userAgent,
		
		gestureStart = function () 
		{
			viewportmeta.content = "width=device-width, minimum-scale=0.25, maximum-scale=1.6";
		},
		
		scaleFix = function () 
		{
			if (viewportmeta && /iPhone|iPad/.test(ua) && !/Opera Mini/.test(ua)) 
			{
				viewportmeta.content = "width=device-width, minimum-scale=1.0, maximum-scale=1.0";
			document.addEventListener("gesturestart", gestureStart, false);
			}
		};
		scaleFix();
	});
		
	asjQuery('a.dropdown-toggle, .dropdown-menu a').on('touchstart', function(e) 
	{
		e.stopPropagation();
	});
		
});
	
	
	
